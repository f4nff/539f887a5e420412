#!/usr/bin/env python
# coding: utf-8

from __future__ import unicode_literals

__license__ = 'Public Domain'
import io
import os
import sys

from operator import itemgetter
from itertools import groupby

from youtube_dl.utils import (
    setproctitle,
    std_headers,
)

from youtube_dl.compat import compat_urlparse

from youtube_dl.YoutubeDL import YoutubeDL

class MyLogger(object):
    def debug(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        print(msg)

def real_parse_main(param):
    x_req_url = param.get('reqUrl','')

    x_req_cookie = param.get('reqCookie','')
    if x_req_cookie != '':
        std_headers['Cookie'] = x_req_cookie

    x_req_user_agent = param.get('reqUserAgent','')
    if x_req_user_agent:
        std_headers['User-Agent'] = x_req_user_agent

    setproctitle('youtube-dl')
    ydl_opts = {
        'logger': MyLogger(),
        'retries': 1,
        'socket_timeout': 10,
    }

    x_req_proxy = param.get('reqProxy','')
    if x_req_proxy != '':
        ydl_opts['proxy'] = x_req_proxy

    ydl_ret = {
        'status': 0,
        'errorMessage': 'unknown error',
    }
    import traceback
    import datetime
    tmp_ie_result = None
    x_short_url = "https://youtu.be/"
    with YoutubeDL(ydl_opts) as ydl:
        ie = ydl.get_info_extractor('Youtube')
        if x_req_url.startswith(x_short_url):
            x_param_pos = x_req_url.find("?")
            if x_param_pos > 0:
                x_req_vid = x_req_url[len(x_short_url): x_param_pos]
            else:
                x_req_vid = x_req_url[len(x_short_url):]
            x_req_url = str.format("https://www.youtube.com/watch?v=%s" % (x_req_vid))
        elif x_req_url.find("?") > 0 and x_req_url.find("list=") > 0:
            x_req_param = compat_urlparse.parse_qs(x_req_url[x_req_url.find("?") + 1:])
            x_req_vid_obj = x_req_param.get('v',None)
            if not x_req_vid_obj is None and isinstance(x_req_vid_obj, list) and len(x_req_vid_obj) > 0:
                x_req_url = str.format("https://www.youtube.com/watch?v=%s" % (x_req_vid_obj[0]))
        if ie.suitable(x_req_url):
            ie = ydl.get_info_extractor(ie.ie_key())
            try:
                ie_result = ie.extract(x_req_url)
                if ie_result is None:
                   pass
                if isinstance(ie_result, list):
                   pass
                if ie_result and ie_result.get('formats',None) is not None:
                   tmp_ie_result = ie_result

                audio_url_list = []
                video_url_list = []
                if tmp_ie_result:
                    tmp_title = ie_result.get('title', 'None')
                    tmp_formats = ie_result.get('formats')
                    audio_key_dict = { "mp4a.40.2": 1000, "vorbis": 800, "opus":500 }
                    video_key_dict = { "p60": 5000, "p": 4000 }
                    vcodec_key_dict = { "vp9.2": 800, "vp9": 500}
                    tmp_idx = 0
                    for tmp_format in tmp_formats:
                        tmp_idx = tmp_idx + 1
                        format_note = str(tmp_format.get('format_note', ''))
                        vcodec = tmp_format.get('vcodec', '')
                        acodec = tmp_format.get('acodec', '')
                        file_ext = tmp_format.get('ext','')
                        file_size = tmp_format.get('filesize', '')
                        if str(file_size).isdigit():
                            if acodec != 'none' and 'audio' in format_note:
                                tmp_label = format_note + "/" + acodec
                                audio_url_item = {
                                    'fileSize': file_size,
                                    'fileName': tmp_title,
                                    'fileLabel': tmp_label,
                                    'fileType': 'audio',
                                    'urlLink': tmp_format.get('url',''),
                                    'vcodec': vcodec,
                                    'acodec': acodec,
                                    'format_note': format_note,
                                    'ext': file_ext,
                                    'group_key': acodec,
                                    'order_idx': audio_key_dict.get(acodec,0),
                                    'nextIdx': 0,
                                    'mergeAction': 0
                                }
                                audio_url_list.append(audio_url_item)
                            elif vcodec != 'none' and format_note.find('p') > 0:
                                tmp_label = format_note + "/" + vcodec
                                tmp_group_key = format_note[0:format_note.find('p')]
                                if tmp_group_key.isdigit():
                                    tmp_order_key = format_note[format_note.find('p'):].lower()
                                    tmp_order_idx = 0
                                    if tmp_order_key.find('hdr') > 0:
                                        tmp_order_idx = 6000
                                    else:
                                        tmp_order_idx = video_key_dict.get(tmp_order_key, 0)
                                    video_url_item = {
                                        'fileSize': file_size,
                                        'fileName': tmp_title,
                                        'fileLabel': tmp_label,
                                        'fileType': 'video',
                                        'urlLink': tmp_format.get('url', ''),
                                        'vcodec': vcodec,
                                        'acodec': acodec,
                                        'format_note': format_note,
                                        'ext': file_ext,
                                        'group_key': int(tmp_group_key),
                                        'order_idx': tmp_order_idx + vcodec_key_dict.get(vcodec,0),
                                        'nextIdx': 0,
                                        'mergeAction': 0
                                    }
                                    video_url_list.append(video_url_item)
                xdown_sort_url_list = []
                audio_sort_url_list = []
                xdown_idx = 0
                if len(audio_url_list) > 0:
                    audio_url_list = sorted(audio_url_list, reverse=True, key=itemgetter('order_idx', 'fileSize'))
                    for item_url in audio_url_list:
                        xdown_idx = xdown_idx + 1
                        item_url['fileIdx'] = xdown_idx
                        audio_sort_url_list.append(item_url)
                    xdown_sort_url_list = audio_sort_url_list
                if len(video_url_list) > 0:
                    video_sort_list = sorted(video_url_list, reverse=True, key=itemgetter('group_key'))
                    video_group_url_list = groupby(video_sort_list, itemgetter('group_key'))
                    video_idx = 0
                    audio_list_size = len(audio_sort_url_list)
                    print("audio list size === ", audio_list_size)
                    for item_key, item_val in video_group_url_list:
                        item_sort_list = sorted(list(item_val), reverse=True, key=itemgetter('order_idx'))
                        if len(item_sort_list) > 0:
                            xdown_idx = xdown_idx + 1
                            item_sort_first_line = item_sort_list[0]
                            item_sort_first_line['fileIdx'] = xdown_idx
                            tmp_group_key = item_sort_first_line.get('group_key',0)
                            if audio_list_size > 0 and str(tmp_group_key).isdigit():
                                next_file_idx = 0
                                if tmp_group_key >= 720:
                                    next_file_idx = audio_sort_url_list[0]['fileIdx']
                                else:
                                    video_idx = video_idx + 1
                                    if audio_list_size > video_idx:
                                        next_file_idx = audio_sort_url_list[video_idx]['fileIdx']
                                    else:
                                        next_file_idx = audio_sort_url_list[audio_list_size - 1]['fileIdx']
                                if next_file_idx > 0:
                                    item_sort_first_line['nextIdx'] = next_file_idx
                                    item_sort_first_line['mergeAction'] = 1
                            xdown_sort_url_list.append(item_sort_first_line)
                if len(xdown_sort_url_list) > 0:
                    ydl_ret['status'] = 1
                    ydl_ret['errorMessage'] = ''
                    ydl_ret['reqUrlList'] = xdown_sort_url_list
            except Exception as e:
                with open('plugin_exception.log', 'w') as f:
                    traceback.print_exc(file=f)
                ydl_ret['errorMessage'] = str(e) + '\r\n' + 'please check log file plugin_exception.log'

    return ydl_ret

if __name__ == '__main__':
    url = "https://youtu.be/XN2MMzN34DU?list=RDXN2MMzN34DU"
    param = {
        'reqUrl': url,
    }
    tmp_ret = real_parse_main(param)
    print(tmp_ret)
