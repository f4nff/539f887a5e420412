var port = null;

function postMessage2XDown(linkUrl) {
  if (linkUrl && (linkUrl.startsWith("https://") || linkUrl.startsWith("http://") || linkUrl.startsWith("ftp://") || linkUrl.startsWith("magnet:?xt=urn:btih:")) ) {
    var xDownData = {
      linkType: 0
    };
    if(linkUrl.startsWith("https://") || linkUrl.startsWith("http://") || linkUrl.startsWith("ftp://")) {
      xDownData.linkType = 1;
      xDownData.linkList = [{linkTxt :linkUrl}];
      xDownData.httpHeaders = {
        'User-Agent': navigator.userAgent
      }
    } else if (linkUrl.startsWith("magnet:?xt=urn:btih:")) {
      xDownData.linkType = 2;
      xDownData.linkMagnet = linkUrl;
    }
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
      chrome.tabs.sendMessage(tabs[0].id, {XDownData: JSON.stringify(xDownData)}, function(response) {});  
    });
  } else {
    var unsupportedTxt = chrome.i18n.getMessage("unsupported");
    if(!unsupportedTxt) {
      unsupportedTxt = "url link unsupported";
    }
    alert(unsupportedTxt)
  }
}

function genericOnClick(info, tab) { 
  postMessage2XDown(info.linkUrl); 
} 
function selectionOnClick(info, tab) { 
  postMessage2XDown(info.selectionText); 
}

var usedXDownTxt = chrome.i18n.getMessage("usedXDown");
if (!usedXDownTxt) {
  usedXDownTxt = "Use XDown download link";
}
var usedXDownSelTxt = chrome.i18n.getMessage("usedXDownSel");
if (!usedXDownSelTxt) {
  usedXDownSelTxt = "Use XDown download to select";
}
var link = chrome.contextMenus.create({"title": usedXDownTxt,"contexts":["link"],"onclick":genericOnClick}); 
var selection = chrome.contextMenus.create({"title": usedXDownSelTxt,"contexts":["selection"],"onclick":selectionOnClick}); 


//connect to native host and get the communicatetion port  
function connectToNativeHost(msg)
{
  var nativeHostName = "org.xdown.xmsg";
  port = chrome.runtime.connectNative(nativeHostName);
  console.log(port);
  port.onMessage.addListener(onNativeMessage);
  port.onDisconnect.addListener(onDisconnected);
  port.postMessage({message: msg});
}

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.type == "launch"){
      connectToNativeHost(request.message);
    }
    return true;
  });

//onNativeDisconnect  
function onDisconnected()
{
  console.log('onDisconnected:',chrome.runtime.lastError);
  port = null;
}

function onNativeMessage(message) {
  console.log('recieved message from native app: ' + JSON.stringify(message));
}

