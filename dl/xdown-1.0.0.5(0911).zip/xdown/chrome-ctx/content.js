var launch_message;
document.addEventListener('ADD-XDOWM-EVENT', function(evt) {
 　　chrome.runtime.sendMessage({type: "launch", message: evt.detail}, 
 	function(response) {
 　　});
}, false);

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	if (request['XDownData']) {
		var evt = document.createEvent("CustomEvent");
		evt.initCustomEvent('ADD-XDOWM-EVENT', true, false, request['XDownData']);
		document.dispatchEvent(evt);
		sendResponse('');
	}
});